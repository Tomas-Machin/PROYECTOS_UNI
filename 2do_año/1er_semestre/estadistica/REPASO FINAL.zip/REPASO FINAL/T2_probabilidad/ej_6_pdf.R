
## EJERCICIO 6 DEL PDF:
# En una carrera participan 7 atletas, 

# ¿Cuantas listas de llegada son posibles? 

  solucion = factorial(7) # 5040

# Si hay 3 ingleses, 2 franceses, un portugues y un español, 

# ¿de cuantas maneras pueden figurar en la lista de llegada las banderas nacionales?

  solucion = factorial(7) / (factorial(3) * factorial(2) * factorial(1) * factorial(1))
  # 420