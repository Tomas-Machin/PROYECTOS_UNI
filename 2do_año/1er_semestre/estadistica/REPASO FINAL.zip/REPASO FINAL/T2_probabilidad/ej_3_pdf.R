
## EJERCICIO 3 DEL PDF:
# ¿Cuantas palabras distintas de 8 letras pueden formarse con a,a,a,b,b,c,c,d?

  #  problema de MISSISSIPPI
  # a = 3, b = 2, c = 2, d = 1

  solucion = factorial(8) / (factorial(3) * factorial(2) * factorial(2) * factorial(1))
  solucion  # 1680
  